select ST_Asewkt(ST_SnapToGrid(the_geom,0.00001)) from loadedshp;

